#include <stdio.h>
int w[] = {0,10,3,4,5,4};
int v[] = {0,24,2,9,10,9};
const int n = sizeof(w) / sizeof(w[0]);
const int c = 13;
int p[n][c+1];
int a[n][c+1];
void knapsack(){
	for(int i = 1; i < n; i++){
		for(int j = 1; j <= c; j++){
			while(j < w[i]){
				p[i][j] = p[i-1][j];
				j++;
			}
			if((v[i] + p[i-1][j - w[i]]) > p[i-1][j]){
				p[i][j] = v[i] + p[i-1][j - w[i]];
				a[i][j] = 1;
			}
			else{
				p[i][j] = p[i-1][j];
			}
		}
	}
}
void rcc(){
	for(int i = n - 1, j = c; i > 0; i--){
		if(a[i][j] == 1){
			j -= w[i];
			printf("%d ",i);
		}
	}
}
int main(){
	knapsack();
	for(int i=1;i<n;i++){
		for(int j=1;j<=c;j++)
			printf("%4d",p[i][j]);
		printf("\n");
	} 
	printf("\n");
	for(int i=1;i<n;i++){
		for(int j=1;j<=c;j++)
			printf("%4d",a[i][j]);
		printf("\n");
	}
	printf("\nѡ�����Ʒ�ǣ�");
	rcc();
} 
