#include <stdio.h>
#include <stdlib.h>
#define Max 10
#define Finity 1000
int tnum; //�ڵ���
int bian;//�߸���
int a[Max][Max];//�ڽӾ���
int x[Max]={0,3,2,5,1,4},bestx[Max];//ǰ��Ϊ��ǰ�⣬����Ϊ��ǰ���Ž� 
int cc=0,bestc=Finity;

void swap(int t,int i){
    int temp;
    temp = x[t]; 
    x[t] = x[i];
    x[i] = temp;
}

void bactrack(int i){
    int j,k;
    if(i==tnum){
        if(a[x[tnum-1]][x[tnum]]!=Finity && a[x[tnum]][x[1]]!=Finity && (cc+a[x[tnum-1]][x[tnum]]+a[x[tnum]][x[1]] <= bestc || bestc ==Finity)){
            for(j=1;j<=tnum;j++) bestx[j] = x[j];
            bestc = cc + a[x[tnum-1]][x[tnum]] + a[x[tnum]][x[1]];
            printf("\nbestx[Max]:");
            for(i=1;i<=tnum;i++) printf("%-5d",bestx[i]);
            printf("%-5d",bestx[1]);
            printf("\nbestc:%d",bestc);
        }
    }else{
        for(j=i;j<=tnum;j++){
            if(i==1){
                swap(i,j);
                bactrack(i+1);
                swap(i,j);
            }else{
                if(a[x[i-1]][x[j]]!=Finity && (cc+a[x[i-1]][x[j]]<bestc || bestc ==Finity)){
                    swap(i,j);
                    cc = cc+a[x[i-1]][x[i]];
                    bactrack(i+1);
                    cc-=a[x[i-1]][x[i]];
                    swap(i,j);
                }
            }
        }
    }
}

//a�ڽӾ����i=1 j=1��ʼ��
int main(){
    int i,j,k;
    int one,two,num;
    printf("�����������:");
    scanf("%d",&tnum);
    printf("���������:");
    scanf("%d",&bian);
    //��ʼ���ڽӾ����x��bestx����
    for(i=0;i<=tnum;i++)
        for(j=0;j<=tnum;j++)
            a[i][j]=Finity;
    printf("���������Ϣ��\n");
    for(k=0;k<bian;k++){
        scanf("%d%d%d",&one,&two,&num);
        a[one][two] = num;
        a[two][one] = num;
    }
    printf("�������£�\n");
    for(i=1;i<=tnum;i++){
        for(j=1;j<=tnum;j++) printf("%-5d",a[i][j]);
        printf("\n");
    }
    printf("\nx���������£�");
    for(i=0;i<=tnum;i++) printf("%-5d",x[i]);
    bactrack(1);
}

/*
5 8
1 2 18
1 3 10
3 4 20
4 5 12
2 5 15
1 4 28
3 2 14
2 4 16
���Ϊ75
*/
