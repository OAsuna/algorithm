#include <iostream>
#include <string.h>
using namespace std;

/*
1 2
1 3
1 4
2 3
2 4
2 5
3 4
4 5
*/
int n=5;//n������
int m=4;//m����ɫ
int k=8;//k����
int sum=0;//ɫ����
int x[100];//��ɫ���
int a[100][100];//�ڽӾ���


bool check(int t)
{
    for(int j=1;j<t;j++)
    {
        if(a[j][t]==1&&x[j]==x[t])
            return false;
    }
    return true;
}

void color(int i)
{
    if(i>n)
    {
        sum++;
        for(int j=1;j<=n;j++)
        {
            printf("%d ",x[j]);
        }
        printf("\n");
        return;
    }
    else
    {
        for(int j=1;j<=m;j++)
        {
            x[i]=j;
            if( check(i) )
                color(i+1);
            x[i]=0;
        }
    }
    return;
}

int main()
{
    memset(a,0,sizeof(a));
    int x,y;
    for(int i=1;i<=k;i++)
    {
        scanf("%d%d",&x,&y);
        a[x][y]=1;
        a[y][x]=1;

    }
    color(1);
    printf("sum = %d",sum);
    return 0;
}
