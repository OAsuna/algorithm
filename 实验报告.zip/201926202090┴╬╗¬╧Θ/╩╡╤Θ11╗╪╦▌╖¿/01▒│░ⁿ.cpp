#include <iostream>

using namespace std;

int n=5;//��Ʒ����
int capa=30;//��������
int v[5]={8,50,12,21,10};//ÿ����Ʒ�ļ�ֵ
int w[5]={3,20,5,10,5};//ÿ����Ʒ������
int bestx[5];
int bestv;//��ǰ����ܼ�ֵ
int x[5];

void backtrack(int k,int cw,int cv)
{
    if(k>n)
    {
        if(cv>bestv)
        {
            bestv = cv;
            for(int i=0;i<n;i++)
            {
                bestx[i] = x[i];
            }
        }
    }
    else
    {
        for(int i=1;i>=0;i--)
        {
            x[k]=i;
            if(i==1)
            {
                if( (cw+w[k])<=capa )
                {
                    cw = cw+w[k];
                    cv = cv+v[k];
                    backtrack(k+1,cw,cv);
                    cw = cw-w[k];
                    cv = cv-v[k];
                }
            }
            else
            {
                backtrack(k+1,cw,cv);
            }
        }
    }
}

int main()
{
    int cv=0;//��ǰ�ܼ�ֵ
    int cw=0;//��ǰ������
    backtrack(1,cw,cv);
    printf("����ֵ:%d",bestv);
    printf("\n���Ž�:");
    for(int i=0;i<n;i++)
    {
        printf("%d  ",bestx[i]);
    }
    return 0;
}
