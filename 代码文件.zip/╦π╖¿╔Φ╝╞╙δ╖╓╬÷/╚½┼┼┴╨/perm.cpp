#include <stdio.h>
void swap(int a[], int i, int j){
	int x=a[i];
	a[i]=a[j];
	a[j]=x;
}
void print(int a[],int n){
	for(int i = 0; i < n; i++){
		printf("%d ",a[i]);
	}
	printf("\n");
}
void perm(int a[], int p, int q){
	if(p == q){
		print(a,q+1);
	}
	else{
		for(int i = p; i <= q; i++){
			swap(a,p,i);
			perm(a,p+1,q);
			swap(a,p,i);
		}
	}
}
int main(){
	int a[9]={1,2,3,4,5,6,7,8,9};  
	perm(a,0,8);
	return 0; 
} 
