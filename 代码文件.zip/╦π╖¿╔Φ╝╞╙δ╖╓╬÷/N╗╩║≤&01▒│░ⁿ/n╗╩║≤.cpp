#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <math.h>
#define N 5      //�ʺ���� 
using namespace std;
int sum=0;

void print(int n,int *x)
{
	for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(j==x[i])
                cout<<" #";
            else
                cout<<" 0";
        }
        cout<<endl;
    }
    cout<<endl;
}
bool Place(int k,int i,int *x) //�ж������ʺ��Ƿ���ͬһ�л���ͬһб����
{
   	for (int j=0;j<k;j++)
	   	if ((x[j]==i)||(abs(x[j] -i)==abs(j-k))) 
		   return false;
   	return true;
}
void NQueens(int k,int n,int *x) 
{
    for (int i=0;i<n;i++)
    {
        if(Place(k,i,x))                                       
        {
            x[k]=i;
            if (k==n-1)    
            {
                sum++;
                print(n,x);//������п��н�
            }
            else
            {
               NQueens(k+1,n,x);
            }
       }
    }
}
int main()
{
    int x[N];
    for(int i=0;i<N;i++) x[i]=-1;
    NQueens(0,N,x);
    cout<<N<<"�ʺ���"<<sum<<"�ֽ⣡"<<endl;
    return 0;
}

