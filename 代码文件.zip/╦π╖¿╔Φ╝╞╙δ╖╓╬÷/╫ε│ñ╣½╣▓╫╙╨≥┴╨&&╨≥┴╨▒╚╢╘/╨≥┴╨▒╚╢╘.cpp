#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXLEN 100
char x[MAXLEN];  //����x
char y[MAXLEN];  //����y
int c[MAXLEN][MAXLEN];  //������бȶԳͷ���
char s1[MAXLEN];  //ƥ��������x
char s2[MAXLEN];  //ƥ��������y
int p=0;   //s1[]���±�
int q=0;   //s2[]���±�

int min(int x,int y){
    if(x>=y)
        return y;
    else
        return x;
}

void xulie(int m,int n){
    int i,j;
    for(i = 0; i <= m; i++)
        c[i][0] = 2 * i;   //��϶ƥ��ͷ���
    for(j = 1; j <= n; j++)
        c[0][j] = 2 * j;
    for(i = 1; i <= m; i++){
        for(j = 1; j <= n; j++){
            if(x[i-1] == y[j-1])
                //�����ǰ�ַ����
                c[i][j] = min(min(c[i-1][j-1], c[i-1][j]+2), c[i][j-1] + 2);
            else
                //�����ǰ�ַ������ 
                c[i][j] = min(min(c[i-1][j-1] + 3, c[i-1][j] + 2), c[i][j-1] + 2);
        }
    }
}

void XL_Print(int i,int j){
    int a = 0;
    if(i == 0 || j == 0){
        if(i == 0 && j == 0){
            return;
        }
        else if(i == 0 && j != 0){ 
            for(a = j; a > 0; a--){
                s1[p++] = '_';
                s2[q++] = y[a-1];
            }
        }
        else if(i != 0 && j == 0){
            for(a = i; a > 0; a--){
                s2[q++] = '_';
                s1[p++] = x[a-1];
            }
        }
    }
    else{
    	if(c[i][j] == c[i-1][j] + 2){
            s1[p++] = x[i-1];
            s2[q++] = '_';
            XL_Print(i-1, j);
        }
        else if(c[i][j] == c[i][j-1] + 2){
            s1[p++] = '_';
            s2[q++] = y[j-1];
            XL_Print(i, j-1);
        }
    	else{
    		s1[p++] = x[i-1];
            s2[q++] = y[j-1];
            XL_Print(i-1, j-1);
		} 
    }
}
int main()
{
    int m,n;
    printf("����������x:\n");
    scanf("%s",x);
    printf("����������y:\n");
    scanf("%s",y);
    m = strlen(x);
    n = strlen(y);
    xulie(m,n);
    XL_Print(m,n);
    printf("\n��С�ͷ��֣�%d\n",c[m][n]);
    for(int i=0;i<=m;i++){
    	for(int j=0;j<=n;j++){
    		printf("%3d ",c[i][j]);
    		
		}
		printf("\n");
	}
    int i;
    for(i = p - 1; i >= 0; i--)
        printf("%c ",s1[i]);
    printf("\n");
    for(i = q - 1; i >= 0; i--)
        printf("%c ",s2[i]);
    return 0;
}
