#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXLEN 100
char x[MAXLEN];  //����x
char y[MAXLEN];  //����y
int p=0;   //s1[]���±�
int q=0;   //s2[]���±�
int a[MAXLEN];
int min(int x,int y){
    if(x>=y)
        return y;
    else
        return x;
}

void xulie(int m,int n){
	int x1 = 2, x2 = 0;
	for(int i = 0; i < n; i++){
		a[i] = 2 * i + 2;
	}
    for(int i = 0; i < m; i++){
        for(int j = 0; j < n; j++){
            if(x[i] == y[j])
                x2 = min(min(a[j-1], a[j] + 2), x1 + 2);
            else
                x2 = min(min(a[j-1] + 3, a[j] + 2), x1 + 2);
            printf("%3d ",x2);
            a[j-1] = x1;
			a[j] = x2;
			x1 = x2;
        }
        printf("\n");
        x1=2*i+2,x2=0;
    }
}
int main()
{
    int m,n;
    printf("����������x:\n");
    scanf("%s",x);
    printf("����������y:\n");
    scanf("%s",y);
    m = strlen(x);
    n = strlen(y);
    xulie(m,n);
    printf("\n��С�ͷ��֣�%d\n",a[n-1]);
    return 0;
}
