#include <stdio.h>
int left, right;
int max(int a[], int n){
	int sum = 0,sum1,sum2,l;
	for(int i = 0; i < n; i++){
		sum1=0,sum2=0;
		for(int j = i; j >= 0; j--){
			sum2 += a[j];
			if(sum2 >= sum1){
				sum1 = sum2;
				l = j;
			}
		}
		if(sum1 > sum){
			sum = sum1;
			left = l;
			right = i;
		}
	}
	return sum;
}
int main(){
	int a[] = {1,-2,3,10,-4,7,2,-5};
	int n = sizeof(a) / sizeof(a[0]);
	printf("max=%d\n",max(a,n));
	printf("a[%d]-a[%d]",left,right);
	return 0; 
} 
