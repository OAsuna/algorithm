#include <stdio.h>
int max(int* arr, int sz)//GetMaxAddOfArray
{
    if (arr == NULL || sz <= 1)
        return 0;
    int MAX = arr[0];
    int sum = arr[0];
    for (int i = 1; i < sz; i++)
    {
        if (sum < 0)
            sum = arr[i];
        else
        {
            sum += arr[i];
        }

        if (sum > MAX)
            MAX = sum;
    }
    return MAX;
}
int main(){
	int a[] = {1,-2,3,10,-4,7,2,-5};
	int n = sizeof(a) / sizeof(a[0]);
	printf("max=%d\n",max(a,n));
	return 0; 
}
