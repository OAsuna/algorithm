#include <stdio.h>
int j = 0, l = 1;
void length(int a[], int n){
	int j1 = 0, k = 1;
	for(int i = 0; i < n; i++){
		if(a[i] > a[i+1]){
			j1 = i + 1;
			k = 1;
		}
		else{
			k++;
		}
		if(k > l){
			l = k;
			j = j1;
		}
	}
}
int main(){
	int a[] = {3,8,2,6,12,4,19,26};
	int size = sizeof(a) / sizeof(a[0]);
	length(a,size);
	printf("ԭ���ݣ�");
	for(int i = 0; i < size; i++){
		printf("%d ",a[i]);
	}
	printf("\n������Ӷ�:");
	for(int i = j; i < j+l; i++){
		printf("%d ",a[i]);
	}
}
