#include <stdio.h>
#include <stdlib.h>
void print(int a[], int n){
	for(int i = 0; i < n; i++){
		printf("%d ", a[i]);
	}
} 
void Swap(int* x, int* y){
	int temp = *x;
	*x = *y;
	*y = temp;
}
int random(int p, int r){
	return rand() % (r - p + 1) + p;
}
int Partition(int a[], int p, int r){
	int i = p, j = r + 1;
	Swap(a+p,a+random(p,r));
	int x = a[p];
	while(true){
		while(a[++i] < x && i < r);
		while(a[--j] > x);
		if(i >= j)
			break;
		Swap(a+i, a+j);
	} 
	a[p] = a[j];
	a[j] = x;
	return j;
} 
void QuickSort (int a[], int p, int r){
	if(p < r){
		int q = Partition(a, p, r);
		QuickSort(a, p, q-1);
		QuickSort(a,q+1,r);
	}
}
int main()
{
	int a[10] = {4,3,5,2,1,10,9,6,8,7}; 
	QuickSort(a, 0, 9);
	print(a,10);
	return 0;
}

